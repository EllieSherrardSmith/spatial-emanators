# Simulate dummy hut-trial data from the generative process assumed by
# nested_hill_model.stan: background mortality split into a before-/after-
# average-feeding-time hazard (nu_u, nu_f, both arms), intervention-attributable
# hazards R (repelled before feeding), K (killed before feeding), M (killed
# after feeding) -- each a Hill/log-logistic decay in time and structurally
# zero in control -- plus a Hill-decay deterrence effect on hut entry.
#
# Output is a data frame in the same raw format as before: HutTrial, Hut,
# Treatment, Time, au, du, df, f -- ready for prepare_stan_data() from
# prepare_stan_data.R (that function is unchanged; only the underlying
# generative model and the Stan file have changed).

library(dplyr)

simulate_hut_trial_data_hill <- function(
    n_trials    = 1,
    n_huts      = 6,          # kept even so each arm gets an equal share of huts
    n_days      = 40,
    seed        = 1,
    rotate_huts = TRUE,       # TRUE: Latin-square-style rotation of which hut is "treatment" by day.
    # FALSE: each hut keeps the same arm for the whole trial.
    
    # ---- true parameter values (edit these to explore different scenarios) ----
    pi_true   = 0.65,         # P(would bite absent intervention)
    nu_u_true = 0.05,         # background mortality hazard, before the average feeding time
    nu_f_true = 0.03,         # background mortality hazard, after the average feeding time
    
    # Treatment-only hazards: each is a Hill/log-logistic decay f0 * thalf^n / (thalf^n + t^n)
    R0_true = 0.50, thalf_R_true = 15, nR_true = 2.0,   # repelled before feeding
    K0_true = 0.30, thalf_K_true = 20, nK_true = 2.0,   # killed before feeding
    M0_true = 0.15, thalf_M_true = 25, nM_true = 1.5,   # killed after feeding
    
    rho_R = 0.05, rho_K = 0.05, rho_M = 0.05,           # within-hut overdispersion, ICC scale (treatment rows only)
    
    delta0_true = 0.30, thalf_d_true = 15, nd_true = 2.0,  # deterrence Hill decay
    rho_delta   = 0.05,                                    # deterrence overdispersion, ICC scale
    
    baseline_catch_mean = 15  # mean nightly per-hut catch absent deterrence, before Poisson noise
) {
  set.seed(seed)
  
  hill_decay <- function(t, f0, thalf, n) f0 * thalf^n / (thalf^n + t^n)
  rbeta_mv   <- function(n_draw, mean, phi) rbeta(n_draw, mean * phi, (1 - mean) * phi)
  
  phi_R <- (1 - rho_R) / rho_R
  phi_K <- (1 - rho_K) / rho_K
  phi_M <- (1 - rho_M) / rho_M
  
  rows <- list()
  
  for (trial in seq_len(n_trials)) {
    
    fixed_arm <- rep(0:1, length.out = n_huts)
    
    for (day in seq_len(n_days)) {
      
      arm_this_day <- if (rotate_huts) {
        (seq_len(n_huts) + day) %% 2
      } else {
        fixed_arm
      }
      
      # Nightly mosquito-abundance multiplier shared by every hut that night.
      night_multiplier <- rlnorm(1, meanlog = 0, sdlog = 0.3)
      
      # True deterrence at this trial-day (Hill decay), relative to the control reference.
      delta_day <- hill_decay(day, delta0_true, thalf_d_true, nd_true)
      
      for (hut in seq_len(n_huts)) {
        arm <- arm_this_day[hut]
        
        entry_rate <- baseline_catch_mean * night_multiplier *
          if (arm == 1) (1 - delta_day) else 1
        
        N_j <- rpois(1, lambda = max(entry_rate, 0.1))
        if (N_j == 0) next   # an empty catch just contributes no row for this hut-night
        
        if (arm == 1) {
          meanR <- hill_decay(day, R0_true, thalf_R_true, nR_true)
          meanK <- hill_decay(day, K0_true, thalf_K_true, nK_true)
          meanM <- hill_decay(day, M0_true, thalf_M_true, nM_true)
          
          R <- rbeta_mv(1, meanR, phi_R)
          K <- rbeta_mv(1, meanK, phi_K)
          M <- rbeta_mv(1, meanM, phi_M)
        } else {
          R <- 0; K <- 0; M <- 0   # structural constraint: R = K = M = 0 in control
        }
        
        A  <- 1 - (1 - nu_u_true) * (1 - K)   # combined hazard, before the average feeding time
        hF <- 1 - (1 - nu_f_true) * (1 - M)   # combined hazard, after the average feeding time
        
        p <- c(
          au = (1 - A) * (1 - hF) * ((1 - pi_true) + pi_true * R),   # alive, unfed
          du = A + (1 - A) * hF * ((1 - pi_true) + pi_true * R),      # dead,  unfed
          df = pi_true * (1 - R) * (1 - A) * hF,                     # dead,  fed
          f  = pi_true * (1 - R) * (1 - A) * (1 - hF)                # alive, fed
        )
        p <- p / sum(p)   # guard against floating-point drift before rmultinom
        
        counts <- as.vector(rmultinom(1, N_j, p))
        
        rows[[length(rows) + 1]] <- data.frame(
          HutTrial  = trial,
          Hut       = hut,
          Treatment = arm,
          Time      = day,
          au = counts[1], du = counts[2], df = counts[3], f = counts[4]
        )
      }
    }
  }
  
  bind_rows(rows)
}

# ---- Quick-start: simulate, prepare, fit, and sanity-check recovery ----
#
raw_hill <- simulate_hut_trial_data_hill()
# write.csv(raw, "dummy_hut_trial_data_hill.csv", row.names = FALSE)
#
source("prepare_stan_data.R")     # unchanged -- same raw format, same aggregation logic
stan_data_hill <- prepare_stan_data(raw_hill)
#
library(cmdstanr)
mod_hill <- cmdstan_model("stan_code/multinomial_hill.stan")
fit_hill <- mod_hill$sample(data = stan_data_hill, chains = 4, iter_warmup = 1000, iter_sampling = 1000, seed = 1, parallel_chains = 4)

## And interrogate the results
fit_hill$summary(variables = c("pi", "nu_u", "nu_f",
                               "R0", "thalf_R", "nR",
                               "K0", "thalf_K", "nK",
                               "M0", "thalf_M", "nM",
                               "delta0", "thalf_d", "nd"))

bayesplot::mcmc_trace(fit_hill$draws(c("pi", "nu_u", "nu_f",
                                  "R0", "thalf_R", "nR",
                                  "K0", "thalf_K", "nK",
                                  "M0", "thalf_M", "nM",
                                  "delta0", "thalf_d", "nd")))

draws_hill <- fit_hill$draws(format = "df", variables = c("pi", "nu_u", "nu_f",
                                                     "R0", "thalf_R", "nR",
                                                     "K0", "thalf_K", "nK",
                                                     "M0", "thalf_M", "nM",
                                                     "delta0", "thalf_d", "nd"))


### What do these values mean in practice?
### Generate mosquito outcomes

time = 1:32
trt = c(0,1)

p_R = p_K = p_M = p_det = array(dim = c(nrow(draws_hill),length(time)))

for(t in 1:length(time)){
  for(i in 1:nrow(draws_hill)){
    p_R[i,t] <- draws_hill$R0[i] * (1 / (1 + (t/draws_hill$thalf_R[i])^draws_hill$nR[i]))
    p_K[i,t] <- draws_hill$K0[i] * (1 / (1 + (t/draws_hill$thalf_K[i])^draws_hill$nK[i]))
    p_M[i,t] <- draws_hill$M0[i] * (1 / (1 + (t/draws_hill$thalf_M[i])^draws_hill$nM[i]))
    p_det[i,t] <- draws_hill$delta0[i] * (1 / (1 + (t/draws_hill$thalf_d[i])^draws_hill$nd[i]))
  }  
}

p_A <- 1 - (1 - draws_hill$nu_u) * (1 - p_K)
p_hF <- 1 - (1 - draws_hill$nu_f) * (1 - p_M)

# Full model with SE impacts
prob_outcome_au = (1 - p_A) * (1 - p_hF) * ((1 - draws_hill$pi) + draws_hill$pi * p_R)
prob_outcome_du = p_A + (1 - p_A) * p_hF * ((1 - draws_hill$pi) + draws_hill$pi * p_R)
prob_outcome_df = draws_hill$pi * (1 - p_R) * (1 - p_A) * p_hF
prob_outcome_f = draws_hill$pi * (1 - p_R) * (1 - p_A) * (1 - p_hF)

# Simplified model without SE impacts
prob_outcome_au_c = (1 - draws_hill$nu_u) * (1 - draws_hill$nu_f) * (1 - draws_hill$pi)
prob_outcome_du_c = draws_hill$nu_u + (1 - draws_hill$nu_u) * draws_hill$nu_f * (1 - draws_hill$pi)
prob_outcome_df_c = draws_hill$pi * (1 - draws_hill$nu_u) * draws_hill$nu_f
prob_outcome_f_c = draws_hill$pi * (1 - draws_hill$nu_u) * (1 - draws_hill$nu_f)

# Treatment probabilities include time-dependency
outcome_prob_res_hill <- 
  bind_rows(
    data.frame(
      au = colMeans(prob_outcome_au),
      du = colMeans(prob_outcome_du),
      df = colMeans(prob_outcome_df),
      f = colMeans(prob_outcome_f)) |> 
      mutate(arm = 1,
             time = time)) |> 
  pivot_longer(cols = c("au", "du", "df", "f"))

# Control probabilities do not change through time
controls_hill <- data.frame(
  au = mean(prob_outcome_au_c),
  du = mean(prob_outcome_du_c),
  df = mean(prob_outcome_df_c),
  f = mean(prob_outcome_f_c)) |> 
  mutate(arm = 0) |> 
  pivot_longer(cols = c("au", "du", "df", "f"))


# Get dummy data in plotable format
hut_outcomes_hill <- data.frame(stan_data_hill$y,
                           time = stan_data_hill$time,
                           arm = stan_data_hill$arm,
                           n = rowSums(stan_data_hill$y))

## Plot trial outcomes and model fit
hut_outcomes_hill |> 
  tidyr::pivot_longer(cols = c(au, du, df, f)) |> 
  ggplot() +
  geom_point(aes(x = time, y = value/n, color = name), size = 0.5) +
  geom_line(data = outcome_prob_res_hill, aes(x = time, y = value, color = name)) +
  geom_hline(data = controls_hill, aes(yintercept = value, color = name)) +
  facet_grid(arm~name) +
  theme_bw() + theme(strip.background = element_rect(fill = "white"))


## Plot each probability through time
mos_prob_res_hill <- bind_rows(
  data.frame(value = colMeans(p_R), time, name = "R"),
  data.frame(value = colMeans(p_K), time, name = "K"),
  data.frame(value = colMeans(p_M), time, name = "M"),
  data.frame(value = colMeans(p_det), time, name = "det"))

mos_prob_res_hill |> 
  ggplot() +
  geom_line(aes(x = time, y = value, color = name)) +
  facet_grid(~name) +
  theme_bw() + theme(strip.background = element_rect(fill = "white")) +
  geom_hline(yintercept = 0, linetype = "dashed")
